import java.util.ArrayList;
import java.util.Queue;

public class ExhaustiveSearch {

  /*
   * Global variables
   */
  public static final int[][] MAP = {
          {0, 1, 2},
          {3, 4, 5},
          {6, 7, 8}
  };
  public static final int ROWS = 3, COLUMNS = 3;
  public static final Tree MY_TREE = new Tree();
  public static final ArrayList<Node> ALL_PATHS = new ArrayList<>();


////////////////////////////////////////////////////////////////////////////////////////////
//                             MAIN METHOD                                                //
////////////////////////////////////////////////////////////////////////////////////////////
  public static void main(String[] args) {
    MY_TREE.root = new Node(0, 0, MAP[0][0]);

    System.out.println("Tree after breadth first adding: ");
    solveByExhaustiveSearch();
    MY_TREE.printTree();

    System.out.println("\n\nAll possible paths: ");
    getPaths(MY_TREE.root);
  }


  /*
   * Solve by exhaustive search method.
   * Implementing the Tree ADT.
   * Breadth first through all nodes and add right and left
   * accordingly to the map values next to the right and below.
   */
  public static void solveByExhaustiveSearch() {

    // Simulate a queue with an array
    ArrayList<Node> nodeList = new ArrayList<>();
    int head = 0, tail = 0;

    // endQueue
    nodeList.add(tail, MY_TREE.root);
    tail++;

    while (head < tail) {

      // deQueue
      Node n = nodeList.get(head);
      head++;

      if (n.row > 3 || n.column > 3) {
        break;
      }

      // endQueue left child
      if (n.left == null && n.row + 1 < 3 && !(MAP[n.row + 1][n.column] == -2)) {
        n.left = new Node(n.row + 1, n.column, "D", MAP[n.row + 1][n.column]);
        nodeList.add(tail, n.left);
        tail++;
      }

      // endQueue right child
      if (n.right == null && n.column + 1 < 3 && !(MAP[n.row][n.column + 1] == -2)) {
        n.right = new Node(n.row, n.column + 1, "R",MAP[n.row][n.column + 1]);
        nodeList.add(tail, n.right);
        tail++;
      }
    }
  }


  /*
  * Get all paths method.
  * Find out all possible paths within the tree,
  * from the root to all branches
   */
  public static void getPaths(Node node) {
    if (node == null)
      return;

    // Append this node to the path array
    ALL_PATHS.add(node);

    // Reached the end
    if (node.left == null && node.right == null) {
      int sum = 0;

      System.out.println();
      for (Node n : ALL_PATHS) {
        if (n.direction == null) System.out.print(n.value + " ");
        else System.out.print(n.value + n.direction + " ");
        sum += n.value;
      }
      System.out.print("-> Steps: " + ALL_PATHS.size() + ", Golds: " + sum + "\n");
    }
    else {
      // otherwise try both subtrees
      getPaths(node.left);
      getPaths(node.right);
    }
  }
}


////////////////////////////////////////////////////////////////////////////////////////////
//                              TREE CLASS                                                //
////////////////////////////////////////////////////////////////////////////////////////////
class Node {
  public int value, row, column;
  public String direction;
  public Node left, right;

  public Node(int v) {
    this.value = v;
    this.left = this.right = null;
  }

  public Node(int row, int column, String direction, int value) {
    this.row = row;
    this.column = column;
    this.value = value;
    this.direction = direction;
    this.left = this.right = null;
  }

  public Node(int row, int column, int value) {
    this.row = row;
    this.column = column;
    this.value = value;
    this.left = this.right = null;
  }
}

class Tree {
  public Node root;

  // this variable is used in the in-oder traversal to check if a tree is a BS
  int lastValue;
  boolean increasing;

  // For display
  int rows = 10;
  int cols = 80;
  char[][] canvas = new char[rows][cols];

  public Tree() {
    root = null;
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        canvas[i][j] = ' ';
      }
    }
  }


  public void printTree() {
    fillCanvas(root, 0, 0, cols);
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        System.out.print(canvas[i][j]);
      }
      // Two blank lines is better than one, right?
      System.out.println();
      System.out.println();
    }
  }


  private void fillCanvas(Node n, int r, int col_start, int col_width) {
    if (n == null) {
      return;
    }
    char[] v = String.valueOf(n.value).toCharArray();
    int start = col_start + col_width / 2 - v.length / 2;
    for (int i = 0; i < v.length; i++) {
      canvas[r][start + i] = v[i];
    }
    fillCanvas(n.left, r + 1, col_start, col_width / 2);
    fillCanvas(n.right, r + 1, col_start + col_width / 2, col_width / 2);
  }
}
