package TreeADT;

import java.util.ArrayList;

public class Tree {

  /*
   * Class defined for Nodes within the Tree
   */
  public static class Node {
    public int value, row, column;
    public String direction;
    public Node left, right;

    public Node(int row, int column, String direction, int value) {
      this.row = row;
      this.column = column;
      this.value = value;
      this.direction = direction;
      this.left = this.right = null;
    }

    public Node(int row, int column, int value) {
      this.row = row;
      this.column = column;
      this.value = value;
      this.left = this.right = null;
    }
  }

  /*
   * Tree class variables
   */
  public int rows = 10;
  public int cols = 70;
  public char[][] canvas = new char[rows][cols];
  public Node root;

  /*
   * Tree class methods
   * -----------------------------------------------------------
   */
  public Tree() {
    root = null;
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        canvas[i][j] = ' ';
      }
    }
  }

  /*
   * Populate tree method.
   * Breadth first through all nodes and add right and left
   * accordingly to the map values next to the right and below.
   */
  public void populateTree(int[][] map, int mapRow, int mapColumn) {

    // Simulate a queue with an array
    ArrayList<Node> nodeList = new ArrayList<>();
    int head = 0, tail = 0;

    // endQueue
    nodeList.add(tail, this.root);
    tail++;

    while (head < tail) {

      // deQueue
      Node n = nodeList.get(head);
      head++;

      if (n.row > mapRow || n.column > mapColumn) {
        break;
      }

      // endQueue left child
      if (n.left == null && n.row + 1 < mapRow && !(map[n.row + 1][n.column] == -2)) {
        n.left = new Node(n.row + 1, n.column, "D", map[n.row + 1][n.column]);
        nodeList.add(tail, n.left);
        tail++;
      }

      // endQueue right child
      if (n.right == null && n.column + 1 < mapColumn && !(map[n.row][n.column + 1] == -2)) {
        n.right = new Node(n.row, n.column + 1, "R", map[n.row][n.column + 1]);
        nodeList.add(tail, n.right);
        tail++;
      }
    }
  }

  /*
   * Get all paths method
   */
  public ArrayList<ArrayList<Node>> findPaths(Node node) {

    if (node == null)
      return new ArrayList<>();

    ArrayList<ArrayList<Node>> paths = new ArrayList<>();

    ArrayList<ArrayList<Node>> leftSubtree = findPaths(node.left);
    ArrayList<ArrayList<Node>> rightSubtree = findPaths(node.right);

    for (ArrayList<Node> path : leftSubtree) {
      ArrayList<Node> newPath = new ArrayList<>();
      newPath.add(node);
      newPath.addAll(path);
      paths.add(newPath);
    }

    for (ArrayList<Node> path : rightSubtree) {
      ArrayList<Node> newPath = new ArrayList<>();
      newPath.add(node);
      newPath.addAll(path);
      paths.add(newPath);
    }

    if (paths.size() == 0) {
      paths.add(new ArrayList<>());
      paths.get(0).add(node);
    }

    return paths;
  }

  /*
   * Print exhaustive search result method
   */
  public void printResult(ArrayList<ArrayList<Node>> allPaths) {
    int sum = 0;

    for (ArrayList<Tree.Node> path : allPaths) {
      for (Tree.Node n : path) {
        if (n.direction == null)
          System.out.print(n.value + " ");
        else
          System.out.print(n.value + n.direction + " ");

        if (n.value > 0)
          sum += n.value;
      }
      System.out.print("-> Steps: " + path.size() + ", Gold: " + sum);

      // Print the path (directions)
      System.out.print(", Path: ");
      for (Tree.Node n : path) {
        if (n.direction != null)
          System.out.print(n.direction);
      }
      System.out.println();

      sum = 0;
    }
  }

  /*
   * Print tree method.
   * This is a way to visualize the tree in the console
   */
  public void printTree() {
    fillCanvas(this.root, 0, 0, cols);
    for (int i = 0; i < rows; i++) {
      for (int j = 0; j < cols; j++) {
        System.out.print(canvas[i][j]);
      }
      // Two blank lines is better than one, right?
      System.out.println();
      System.out.println();
    }
  }

  private void fillCanvas(Node n, int r, int col_start, int col_width) {
    if (n == null) {
      return;
    }
    char[] v = String.valueOf(n.value).toCharArray();
    int start = col_start + col_width / 2 - v.length / 2;
    System.arraycopy(v, 0, canvas[r], start, v.length);
    fillCanvas(n.left, r + 1, col_start, col_width / 2);
    fillCanvas(n.right, r + 1, col_start + col_width / 2, col_width / 2);
  }
}
