import java.util.Map;
import java.util.Optional;

public class Main {
  public static void main(String[] args) {
    GreedyGnomes greedyGnomes = new GreedyGnomes();
    // greedyGnomes.loadMap(args[0]);
    greedyGnomes.loadMap("src/map.txt");

    // Solve by dynamic programming
    // System.out.println("\nSolved by dynamic programming
    // ------------------------------------");
    // Optional<String[]> dynamicProgrammingResults =
    // greedyGnomes.resolve(GreedyGnomes.Algo.DYNAMIC_PROGRAMMING);
    // dynamicProgrammingResults.ifPresent(strings ->
    // System.out.println(strings[0]));

    // // Solve by Exhaustive search
    // System.out.println("\nSolved by exhaustive search
    // ------------------------------------");

    // Display map
    System.out.println("Display map:");
    greedyGnomes.display();
    System.out.println("\n");

    greedyGnomes.resolve(GreedyGnomes.Algo.EXHAUSTED_SEARCH);
  }
}
