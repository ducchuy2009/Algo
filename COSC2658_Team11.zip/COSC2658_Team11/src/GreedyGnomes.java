import TreeADT.Tree;

import java.io.*;
import java.util.*;

public class GreedyGnomes {

  private final String REGEX_POSITIVE_INTEGER = "^[1-9]\\d*$";

  private int[][] map;

  private int[][] trace_support;
  private boolean trace_visited;

  private int rows;

  private int columns;

  // Exhaustive search variables:
  // private final ArrayList<Tree.Node> ALL_PATHS = new ArrayList<>();
  // End of Exhaustive search variables:

  enum Algo {
    DYNAMIC_PROGRAMMING,
    EXHAUSTED_SEARCH
  }

  public void loadMap(String filePath) {
    List<String> lines = readFile(filePath);
    Optional<int[]> mapParametersOpt = getMapSizes(lines.get(0));
    if (mapParametersOpt.isPresent()) {
      this.rows = mapParametersOpt.get()[0];
      this.columns = mapParametersOpt.get()[1];
      if (rows != lines.size() - 1) {
        System.out.println("Invalid input! Number of rows provided in map parameters " +
            "is not equal to actual number of rows in the map");
      } else {
        this.map = new int[rows][columns];
        for (int i = 0; i < this.map.length; i++) {
          String[] row = lines.get(i + 1).split(" ");
          if (this.map[i].length == row.length) {
            for (int j = 0; j < this.map[i].length; j++) {
              if (!isValidCell(row[j])) {
                System.out.println("Cell " + i + "," + j + " does not contain valid value");
                return;
              } else {
                if (row[j].equals("X")) {
                  this.map[i][j] = -2;
                } else if (row[j].equals(".")) {
                  this.map[i][j] = 0;
                } else {
                  this.map[i][j] = Integer.parseInt(row[j]);
                }
              }
            }
          } else {
            System.out.println("Invalid input! Number of columns provided in map parameters " +
                "is not equal to actual number of cells in row " + i);
          }
        }
      }
    }
  }

  public Optional<String[]> resolve(Algo algo) {
    switch (algo) {
      case DYNAMIC_PROGRAMMING:
        return resolveByDynamicProgramming();
      case EXHAUSTED_SEARCH:
        return resolveByExhaustedSearch();
    }
    return Optional.empty();
  }

  public void display() {
    for (int[] rows : this.map) {
      for (int cell : rows) {
        System.out.print(cell + " ");
      }
      System.out.println();
    }
  }

  private Optional<String[]> resolveByDynamicProgramming() {
    int[][] table = new int[rows][columns];
    int[][] path_gonethrough = new int[rows][columns];
    int[][] trace = new int[rows][columns];
    int best_x = 0;
    int best_y = 0;

    for (int i = 0; i < this.rows; i++) {
      for (int j = 0; j < this.columns; j++) {
        if (i == 0 && j == 0) {
          table[i][j] += Math.max(map[i][j], 0);
          path_gonethrough[i][j] = 1;
          trace[i][j] = -1;
          continue;
        }
        // Check if map[i][j] is X
        if (map[i][j] != -2) {
          table[i][j] += Math.max(map[i][j], 0);

          if (i > 0 && j > 0 && path_gonethrough[i - 1][j] == 1 && path_gonethrough[i][j - 1] == 1) {
            table[i][j] += Math.max(table[i - 1][j], table[i][j - 1]);
            path_gonethrough[i][j] = 1;

            if (table[i - 1][j] > table[i][j - 1]) {
              trace[i][j] = 1; // TOP = 1
            } else {
              trace[i][j] = 0; // LEFT = 0
            }

          } else if (i > 0 && path_gonethrough[i - 1][j] == 1) {
            table[i][j] += table[i - 1][j];
            path_gonethrough[i][j] = 1;
            trace[i][j] = 1;

          } else if (j > 0 && path_gonethrough[i][j - 1] == 1) {
            table[i][j] += table[i][j - 1];
            path_gonethrough[i][j] = 1;
            trace[i][j] = 0;

          }

          if (table[i][j] > table[best_x][best_y]) {
            best_x = i;
            best_y = j;
          }
        }

        System.out.print(table[i][j] + " ");
      }
      System.out.println();
    }

    // output path
    StringBuilder path = new StringBuilder();
    int gold = table[best_x][best_y];
    int step = 0;

    while (best_x != 0 || best_y != 0) {
      // TOP
      if (trace[best_x][best_y] == 1) {
        path.append("D");
        best_x--;
        step++;
      } else {
        path.append("R");
        best_y--;
        step++;
      }
    }

    System.out.println("Steps: " + step);
    System.out.println("Gold: " + gold);
    System.out.println("Path: " + path.reverse());
    return Optional.of(new String[] { "" });

  }

  // the idea is to have the max value of gold at index i,j using exhaustive
  // search search.
  private Optional<String[]> resolveByExhaustedSearch() {
    // int[][] table = new int[rows][columns];
    int best = 0;
    int best_x = 0;
    int best_y = 0;

    for (int i = 0; i < this.rows; i++) {
      for (int j = 0; j < this.columns; j++) {
        trace_visited = false;
        int result = bf(i, j);
        if (result > best && trace_visited == true) {
          best = result;
          best_x = i;
          best_y = j;
        }
      }
    }

    trace_support = new int[rows][columns];
    best = trace(best_x, best_y);
    // output path
    StringBuilder path = new StringBuilder();
    int step = 0;

    while (best_x != 0 || best_y != 0) {
      // TOP
      if (trace_support[best_x][best_y] == 1) {
        path.append("D");
        best_x--;
        step++;
      } else {
        path.append("R");
        best_y--;
        step++;
      }
    }

    System.out.println("Gold: " + best);
    System.out.println("Path: " + path.reverse());
    System.out.println("Steps: " + step);

    return Optional.of(new String[] { "" });
  }

  private int trace(int x, int y) {
    if (x > 0 && y > 0) {
      if (map[x][y] == -2) {
        return -2;
      }

      int d = map[x][y] + trace(x - 1, y);
      int r = map[x][y] + trace(x, y - 1);

      if (d > r) {
        trace_support[x][y] = 1; // D
        return d;
      } else {
        trace_support[x][y] = 0; // R
        return r;
      }

    } else if (x > 0) {
      if (map[x][y] == -2) {
        return -2;
      }

      trace_support[x][y] = 1;
      return (map[x][y] + trace(x - 1, y));

    } else if (y > 0) {
      if (map[x][y] == -2) {
        return -2;
      }

      trace_support[x][y] = 0;
      return (map[x][y] + trace(x, y - 1));

    } else if (x == 0 && y == 0) {
      return map[x][y];

    }

    return 0;
  }

  // return an array of int: [0] = max gold, [1] = previous step; previous step:
  // 1: R, 2: D
  private int bf(int x, int y) {
    if (x > 0 && y > 0) {
      if (map[x][y] == -2) {
        return -2;
      }
      return Math.max((map[x][y] + bf(x - 1, y)), (map[x][y] + bf(x, y - 1)));

    } else if (x > 0) {
      if (map[x][y] == -2) {
        return -2;
      }
      return (map[x][y] + bf(x - 1, y));

    } else if (y > 0) {
      if (map[x][y] == -2) {
        return -2;
      }
      return (map[x][y] + bf(x, y - 1));

    } else if (x == 0 && y == 0) {
      trace_visited = true;
      return map[x][y];

    }

    return 0;
  }

  private Optional<int[]> getMapSizes(String line) {
    String[] parameters = line.split(" ");
    if (parameters.length != 2) {
      System.out.println("Invalid Input! First line must contain exactly two parameters separated by a space");
    } else if (parameters[0].matches("\\d+") && parameters[1].matches(REGEX_POSITIVE_INTEGER)) {
      return Optional.of(new int[] { Integer.parseInt(parameters[0]), Integer.parseInt(parameters[1]) });
    }
    return Optional.empty();
  }

  private List<String> readFile(String filePath) {
    List<String> lines = new ArrayList<>();

    try {
      FileInputStream fis = new FileInputStream(filePath);
      Scanner sc = new Scanner(fis);
      while (sc.hasNextLine()) {
        lines.add(sc.nextLine());
      }
      sc.close();
    } catch (IOException e) {
      e.printStackTrace();
      System.out.println("Invalid file");
    }
    return lines;
  }

  private boolean isValidCell(String cell) {
    return cell.equals("X") || cell.equals(".") || cell.matches(REGEX_POSITIVE_INTEGER);
  }
}
