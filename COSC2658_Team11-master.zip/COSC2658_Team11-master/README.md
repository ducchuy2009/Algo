# GreedyGnomes Problem

## Installation

- The project is developed and tested on Java 11
- To run the project, use IntelliJ to open the root folder
  - The project only takes the first argument as input from user (the name of the map)
  - It can be added using the Edit Configuration panel of IntelliJ
![img.png](img.png)
- The program consists of three stages:
  - Load map: From the input argument, it will find the text file containing the map and load it
  - Solving with Dynamic Programming: It solves the Greedy Gnomes with Dynamic Programming technique and display the results
  - Solving with Exhaustive Search: It solves the Greedy Gnomes with Exhaustive Search technique and display the results
![img_1.png](img_1.png)
## Limitation and Important Notes
- The project only support text file as the provided examples in the "src" folder
- The display of the converted/resolved map is design for maximum three digit value of Gold. If exceeds, the format will be incorrect
- The program will terminate immediately if the given map is not in correct format
- The program ignores all empty lines